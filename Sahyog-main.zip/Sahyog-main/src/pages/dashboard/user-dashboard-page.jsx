import UserDashboardComponent from '../../components/user-dashboard/user-dashboard-component';

const UserDashboard = () => {
  return (
    <div className="h-full">
      <UserDashboardComponent />
    </div>
  );
};

export default UserDashboard;
